package com.iverson.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@Configuration
@ComponentScan("com.iverson.springcore")
public class Client {

	public static void main(String[] args) {


		ApplicationContext context=new AnnotationConfigApplicationContext(Client.class); //eager initializer 
		Employee emp = (Employee) context.getBean("employee");

		System.out.println(emp);//bean scope-->singleton
		// object address
		System.out.println(emp.getAddress());//@Autowired
		
	}

}
