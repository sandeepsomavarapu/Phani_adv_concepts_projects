import re

count=0
matcher=re.finditer("python","python welcome to python python django");
for match in matcher:
	count+=1
	print(match.start(),"  ",match.end())
print("the python occurence:",count)
