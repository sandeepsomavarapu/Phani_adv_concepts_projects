def iseven(x):
	if x%2==0:
		return True
	else:
		return False
l=[3,2,6,8,7,10]
l1=list(filter(iseven,l))
print(l1)

def squareOf(y):
	return y*y
l3=[3,2,6,8,7,10]
l4=list(map(squareOf,l))
print(l4)