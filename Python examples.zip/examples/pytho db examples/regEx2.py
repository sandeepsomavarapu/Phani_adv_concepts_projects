import re
matcher=re.finditer("[^a-zA-Z0-9]","a8b@k9zA")
for match in matcher:
	print(match.start())