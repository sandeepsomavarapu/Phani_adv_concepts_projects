import cx_Oracle
try:
    con=cx_Oracle.connect('softpath/softpath123@localhost')
    cursor=con.cursor()
    sql="insert into spemp4 values(:eno,:ename,:esal,:eaddr)"#positional parameters 
    records=[(200,'Sunny',2000,'Mumbai'),  (300,'Chinny',3000,'Hyd'),  (400,'Bunny',4000,'Hyd')]
    cursor.executemany(sql,records)
    con.commit()
    print("Records Inserted Successfully")
except cx_Oracle.DatabaseError as e:
    if con:
        con.rollback()
        print("There is a problem with sql",e)
finally:
    if cursor:
        cursor.close()
    if con:
        con.close()