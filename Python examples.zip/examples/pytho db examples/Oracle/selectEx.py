import cx_Oracle
try:
    con=cx_Oracle.connect('softpath/softpath123@localhost')
    cursor=con.cursor()
    cursor.execute("select * from spemp4")
    data=cursor.fetchall()
    for row in data:
        print("Employee Number:",row[0])
        print("Employee Name:",row[1])
        print("Employee Salary:",row[2])
        print("Employee Address:",row[3])
except cx_Oracle.DatabaseError as e:
    if con:
        con.rollback()
        print("There is a problem with sql",e)
finally:
    if cursor:
        cursor.close()
    if con:
        con.close()
