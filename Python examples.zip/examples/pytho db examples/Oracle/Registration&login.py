# importing module 
import mysql.connector   
# Create a table in Oracle database 
try:  
    mydb=mysql.connector.connect(host="localhost",user="root",passwd="rpsconsulting",database="ericsson_virtual")
    # Now execute the sqlquery 
    cursor = mydb.cursor()       
    # Creating a table srollno heading which is number     
    #cursor.execute("create table registration (username varchar(10) not null, password varchar(10) not null, phone_number int not null, address varchar(20) not null)")                       
    #print("Table Registration has been created successfully")
    flag=-1   
    choice = input("Please enter 1 to register as a new user, 2 to login with an existing account or 3 to exit: ")   
    while(flag<0):
        if int(choice) == 1:
            print("\n \n \n ***   USER REGISTRATION   ***")                 
            sql_query = ("SELECT * FROM REGISTRATION")
            cursor.execute(sql_query)
            result = cursor.fetchall()            
            uname = input("\nPlease enter your username: ")
            pword = input("Please enter your password: ")
            num= input("Please enter your phone number: ")
            add = input("Please enter your address: ")            
            #if record already exists, change choice to 2 for login            
            for res in result:
                if res[0]==uname and res[1]==pword:
                    choice=2                                       
            #if there is no existing record, insert a new one           
            sql = ('insert into registration (username, password, phone_number, address) values (:username, :password, :phone_number, :address) ')
            cursor.execute(sql, [uname, pword, num, add])
            con.commit()
            print("User has been registered!")
            choice = input("Please enter 1 to register as a new user, 2 to login with an existing account or 3 to exit: ")       
        elif int(choice)==2:           
            matches = 0
            print("\n \n \n ***  LOGIN   ***")
            uname = input("Please enter your username: ")
            pword = input("Please enter your password: ")
            sql=("select * from registration  where username=:username and password=:password")
            cursor.execute(sql, [uname, pword])           
            #is there already an existing record?
            #check for existing record, then flag=1
            sql_query = ("SELECT * FROM REGISTRATION")
            cursor.execute(sql_query)
            result = cursor.fetchall()
            for res in result:
                if res[0]==uname and res[1]==pword:
                    matches = matches + 1
         
            if matches == 0:
                print("User details not found")
                choice = input("Please enter 1 to register as a new user, 2 to login with an existing account or 3 to exit: ")      
            elif matches >0:
                print("Login Successful")
                choice = input("Please enter 1 to register as a new user, 2 to login with an existing account or 3 to exit: ")    
        elif int(choice)==3:
            print("\n \n \n Exiting login screen. Bye!")
            flag=1
            break;
            
        else:
            choice = input("Please enter 1 to register as a new user, 2 to login with an existing account or 3 to exit: ")         
except mysql.connector.DatabaseError as e: 
    print("There is a problem with Oracle", e) 
  
# by writing finally if any error occurs 
# then also we can close the all database operation 
finally: 
    if cursor: 
        cursor.close() 
    if mydb: 
        mydb.close()