import cx_Oracle
try:
    con=cx_Oracle.connect('softpath/softpath123@localhost')
    cursor=con.cursor()
    cursor.execute("delete from spemp4 where eno=200")
    con.commit()
    print("Record Deleted Successfully")
except cx_Oracle.DatabaseError as e:
    if con:
        con.rollback()
        print("There is a problem with sql",e)
finally:
    if cursor:
        cursor.close()
        if con:
            con.close()
			