import cx_Oracle 
con=cx_Oracle.connect('softpath/softpath123@localhost') 
print(con.version) 
con.close()

#py -m pip install cx_Oracle