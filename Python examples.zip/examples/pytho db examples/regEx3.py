import re


m=re.search("python$","python programmig is very easy")
if m!=None:
	print("match is ending with easy ....!")
else:
	print("not ending with easy")
