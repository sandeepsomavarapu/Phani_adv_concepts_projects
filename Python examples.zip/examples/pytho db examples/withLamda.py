l=[3,2,6,8,7,10,34,23]
l1=list(filter(lambda x:x%2==0,l))
print(l1)
l3=[3,2,6,8,7,10,34,23]
l4=list(map(lambda y:y*y ,l))
print(l4)

