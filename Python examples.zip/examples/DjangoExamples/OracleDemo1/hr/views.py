from django.shortcuts import render
from .models import Job
def  list_jobs (request):
    return render(request,'list_jobs.html',{'jobs' : Job.objects.all()})