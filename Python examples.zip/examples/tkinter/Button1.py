from tkinter import *   
  
  
top = Tk()  
  
top.geometry("200x100")  
  
b = Button(top,text = "Simple")  
 #Button(master,option=value)
b.pack()  
  
top.mainloop()  