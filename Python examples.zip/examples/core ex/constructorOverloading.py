class Test:
	def __init__(self,a=None,b=None,c=None):
		print('param constructor')
		
t=Test(12,13)
t1=Test(12,13,14)
t2=Test(12)	
		
		
		
		
		
		
		
		
		
		
		
		
		