import imp
from threading import *
print(current_thread().getName())
current_thread().setName("martin")
print(current_thread().getName())



