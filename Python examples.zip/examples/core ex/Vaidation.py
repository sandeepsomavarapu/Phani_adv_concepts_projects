username=input('enter your username :')
password=input('enter your password :')

if username=='python' and password=='python123':
	print("login success")
	print("welcome")
else:
	print("enter valid credentials")








