class Employee:
 
    company = 'Lti'
 
    @staticmethod
    def add(a, b, c):
        return a + b + c

    @classmethod
    def avg(cls):
        x = cls.add(10, 20, 40)
        return (x / 3)
  
average = Employee.avg()
print('The Average Of three Numbers = ', average)