#option for creating python class
class Employee:
    def __init__(self):
        print('Msg from Employee : Welcome to Tutorial Gateway')
 
class Student():
    def __init__(self):
        print('Msg from Student: Hello World!')
 
class Person(object):
    def __init__(self):
        print('Msg from Person: Welcome to Python Programming')
         
emp = Employee()

std = Student()

per = Person()