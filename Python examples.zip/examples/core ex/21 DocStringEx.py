#   ''''''
#   """"""
# __doc__

def  my_fun():
    """this is docstring message we can define by using three 
    single quotes or double quotes"""
    return None;

#print(my_fun.__doc__)  
help(my_fun)
#