def add(a=10,b=30): #default value of function argument
	res=a+b
	print("sum of two numbers",res)
	
add(a=50)       #value passed baesed on variable name

def sum():
	pass