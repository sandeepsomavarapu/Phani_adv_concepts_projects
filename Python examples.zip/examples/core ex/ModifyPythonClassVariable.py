class Employee:
    company = 'Lti' #class level variable
 
    def func_message(self):
        print('Welcome to Python Programming')
 
emp1 = Employee()
emp2 = Employee()
emp3 = Employee()
 
emp2.company = 'Python' #modifying class variable  using emp2 
emp3.company = 'Apple'  #modifying class variable using emp3
 
emp1.func_message()
 
print(emp1.company)
print(emp2.company)
print(emp3.company)
