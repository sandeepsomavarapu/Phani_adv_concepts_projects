#Python Class method Decorator
 
class Employee:
 
    company = 'welcome'
 
    @classmethod            #decorator
    def message(cls):
        print('The Message is From %s Class' %cls.__name__)
        print('The Company Name is %s' %cls.company)

Employee.message()# calling method without creating an object
print(Employee.company) 
print('-----------')
Employee().message() # Other way of calling classmethod