import threading

print("current executing thread : "+threading.current_thread().getName())