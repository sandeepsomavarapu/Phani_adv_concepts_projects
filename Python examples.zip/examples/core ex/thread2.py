from threading import *
import threading

def display():
	for i in range(1,11):
		print("current executing thread : "+threading.current_thread().getName())#thread-1
		print("child thread")

t=Thread(target=display)
t.start()#starting a thread 
for i in range(1,11):
		print("main thread")