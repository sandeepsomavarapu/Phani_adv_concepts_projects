class Welcome:
    """ this is from student class docstring"""
print(Welcome.__doc__)
help(Welcome)