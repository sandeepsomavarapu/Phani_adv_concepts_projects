import cx_Oracle

try:
    username = input ('Enter username to login')
    password = input ('Enter password to login')
    con = cx_Oracle.connect ("softpath/softpath123@localhost")
    cursor = con.cursor()
    data = cursor.execute("select * from loginpage")
    for row in data:
        if row[0] == username and row[1] == password:
            print ("Login Success:", row[2])
        else:
            print("Enter valid credentials")    

except cx_Oracle.DatabaseError as e:
    if con:
        con.rollback ()
        print ("There is a problem with sql", e)
finally:
    if cursor:
        cursor.close ()
    if con:
        con.close ()