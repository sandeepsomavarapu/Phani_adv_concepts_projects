class Test:
	@staticmethod
	def add(x,y):
		print('addition of two numbers :',x+y)
	@staticmethod
	def mul(x,y):
		print('addition of two numbers :',x*y)
Test.add(100,300)
Test.mul(10,30)