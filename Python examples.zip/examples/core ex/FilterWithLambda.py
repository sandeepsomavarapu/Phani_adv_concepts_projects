list1=[0,2,4,3,5,6,9,10,30]		
l=list(filter(lambda x:x%2==0,list1))
print(l) 

list1=[0,2,4,3,5,6,9,10,30]		
l=list(filter(lambda x:x%2!=0,list1))
print(l) 