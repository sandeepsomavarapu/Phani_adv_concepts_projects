class Employee:
     
    def func_message(self):
        print('Welcome to Python Programming')
 
    @staticmethod
    def func_msg():
        print("Welcome to Lti")
 
    @staticmethod
    def split_string(message):
        return message.split(",")
 
Employee.func_msg()

countries = 'India, China, Japan, USA, UK, Australia, Canada'

 
print(Employee.split_string(countries))
res=Employee.split_string(countries)
print(type(res))