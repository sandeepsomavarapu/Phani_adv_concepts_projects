class Employee:
     
    def func_message(self):
        print('Welcome to Python Programming')
 

    @staticmethod  #static method decorator
    def func_msg():
        print("Welcome to Lti")
 
Employee.func_msg() #calling static method
 
emp = Employee()
emp.func_message()

#diiferent types of methods  instance static 